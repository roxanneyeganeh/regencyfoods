/* Refinements: header state on scroll, gentle section reveal */
(function () {
  "use strict";
  var root = document.documentElement;
  var reduce = window.matchMedia && matchMedia("(prefers-reduced-motion: reduce)").matches;

  root.classList.add("refined");

  var header = document.querySelector(".header");
  function onScroll() { header.classList.toggle("is-scrolled", window.scrollY > 24); }
  window.addEventListener("scroll", onScroll, { passive: true }); onScroll();


  /* reveal */
  if (!reduce && "IntersectionObserver" in window) {
    root.classList.add("rf-anim");
    var els = document.querySelectorAll(".sec-head, .ig-list, .ig-grid, .mx-trust .wrap, .shelf, .mx-salmon-grid, .mx-sl-grid, .stats, .trade-grid, .news .wrap > *");
    var io = new IntersectionObserver(function (es) { es.forEach(function (en) { if (en.isIntersecting) { en.target.classList.add("in"); io.unobserve(en.target); } }); }, { threshold: .12, rootMargin: "0px 0px -6% 0px" });
    els.forEach(function (el) { el.setAttribute("data-reveal", ""); io.observe(el); });
  }
})();
