/* Regency Foods website. No dependencies. */
(function () {
  "use strict";

  /* ------------------------------------------------------------------
     The range. Pecan (£16.45) is the only confirmed price.
     TODO before launch: confirm Almond and Pistachio prices, their
     descriptions and ingredients, and every nutrition figure (the brand
     guidelines mark the pack nutrition values as placeholders too).
     ------------------------------------------------------------------ */
  var RANGE = [
    { id: "almond", name: "Almond", descriptor: "100% Raw Organic", price: 12.95, colour: "var(--yellow)", dot: "#F2C44B", tint: "#FBEBC2",
      pack: "assets/img/pouch-almond-front.webp", back: "assets/img/pouch-almond-back.webp", side: "assets/img/pouch-almond-side.webp",
      about: "Whole, raw organic almonds with a clean, sweet crunch. Perfect for baking, granola, salads and snacking.",
      ingredients: "<b>Almonds</b> (100%).",
      allergy: "For allergens, see ingredients in <b>bold</b>. Packed in a facility that also handles other tree nuts and peanuts.",
      nutrition: [["Energy", "2534 kJ / 612 kcal"], ["Fat", "55.8 g"], ["of which saturates", "4.3 g", 1], ["Carbohydrate", "6.9 g"], ["of which sugars", "4.2 g", 1], ["Fibre", "7.4 g"], ["Protein", "21.1 g"], ["Salt", "0.01 g"]] },
    { id: "pecan", name: "Pecan", descriptor: "Mildly Roasted", price: 16.45, colour: "var(--orange)", dot: "#E85A10", tint: "#FADCCB",
      pack: "assets/img/pouch-pecan-front.webp", back: "assets/img/pouch-pecan-back.webp", side: "assets/img/pouch-pecan-side.webp",
      about: "Hand-selected pecan halves, mildly roasted for a rich, buttery crunch. Rich in healthy fats, vitamin E and minerals like manganese and copper. Perfect for baking, salads and snacking.",
      ingredients: "<b>Pecan nuts</b> (100%).",
      allergy: "For allergens, see ingredients in <b>bold</b>: <b>pecans</b>. Packed in a facility that also handles other tree nuts and peanuts.",
      nutrition: [["Energy", "2895 kJ / 702 kcal"], ["Fat", "70.1 g"], ["of which saturates", "5.7 g", 1], ["Carbohydrate", "5.8 g"], ["of which sugars", "4.3 g", 1], ["Fibre", "4.7 g"], ["Protein", "9.2 g"], ["Salt", "0.01 g"]] },
    { id: "pistachio", name: "Pistachio", descriptor: "Premium Roasted", price: 19.50, colour: "var(--bright)", dot: "#44AF5D", tint: "#D9EFD9",
      pack: "assets/img/pouch-pistachio-front.webp", back: "assets/img/pouch-pistachio-back.webp", side: "assets/img/pouch-pistachio-side.webp",
      about: "Premium pistachios, roasted in the shell for a rich, savoury crunch. Made for the snack bowl, salads, pastry and desserts.",
      ingredients: "<b>Pistachio nuts</b> (100%).",
      allergy: "For allergens, see ingredients in <b>bold</b>. Packed in a facility that also handles other tree nuts and peanuts.",
      nutrition: [["Energy", "2459 kJ / 594 kcal"], ["Fat", "48.5 g"], ["of which saturates", "5.9 g", 1], ["Carbohydrate", "17.6 g"], ["of which sugars", "7.7 g", 1], ["Fibre", "10.3 g"], ["Protein", "20.6 g"], ["Salt", "0.01 g"]] }
  ];
  var BY = {}; RANGE.forEach(function (p) { BY[p.id] = p; });
  var gbp = new Intl.NumberFormat("en-GB", { style: "currency", currency: "GBP" });
  var $ = function (s, r) { return (r || document).querySelector(s); };
  var $$ = function (s, r) { return Array.prototype.slice.call((r || document).querySelectorAll(s)); };
  var reduce = window.matchMedia && matchMedia("(prefers-reduced-motion: reduce)").matches;
  var canHover = window.matchMedia && matchMedia("(hover: hover) and (pointer: fine)").matches;
  function esc(s) { return String(s).replace(/[&<>"]/g, function (c) { return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]; }); }
  var store = {
    get: function (k, d) { try { var v = localStorage.getItem(k); return v ? JSON.parse(v) : d; } catch (e) { return d; } },
    set: function (k, v) { try { localStorage.setItem(k, JSON.stringify(v)); } catch (e) {} }
  };

  /* ---------- Small timer: counts down to local midnight ---------- */
  function tick() {
    var timers = $$("[data-timer]");
    var now = new Date(), mid = new Date(now); mid.setHours(24, 0, 0, 0);
    var s = Math.max(0, Math.floor((mid - now) / 1000));
    var str = String(Math.floor(s / 3600)).padStart(2, "0") + ":" + String(Math.floor(s / 60) % 60).padStart(2, "0") + ":" + String(s % 60).padStart(2, "0");
    timers.forEach(function (t) { t.textContent = str; });
  }
  tick(); setInterval(tick, 1000);
  $$("[data-year]").forEach(function (el) { el.textContent = new Date().getFullYear(); });

  /* ---------- The shelf ---------- */
  var shelf = $("#shelf");
  shelf.innerHTML = RANGE.map(function (p) {
    return '<div class="bay" data-bay="' + p.id + '" style="--c:' + p.colour + '">' +
      '<a class="facing" href="#/product/' + p.id + '" aria-label="' + p.name + ': see the product page">' +
        '<span class="pouch" style="--pm:url(' + p.pack + ')"><img src="' + p.pack + '" alt="Regency Foods ' + p.name + ', ' + p.descriptor.toLowerCase() + ', 1 kg resealable pack" draggable="false"><span class="sheen"></span></span>' +
        '<span class="contact" aria-hidden="true"></span>' +
      '</a>' +
      '<div class="board" aria-hidden="true"></div>' +
      '<div class="sel">' +
        '<div class="top"><div><h3>' + p.name + '</h3><p class="desc">' + p.descriptor + '</p></div>' +
        '<div style="text-align:right"><p class="price">' + gbp.format(p.price) + '</p><p class="unit">' + gbp.format(p.price / 10) + ' / 100 g</p></div></div>' +
        '<div class="row"><span class="qty" role="group" aria-label="Quantity of ' + p.name + '"><button type="button" data-step="-1" aria-label="Decrease">−</button><output data-q>1</output><button type="button" data-step="1" aria-label="Increase">+</button></span>' +
        '<button class="btn btn--green add" type="button" data-add="' + p.id + '">Add to basket</button></div>' +
        '<a class="more" href="#/product/' + p.id + '/nutrition">Ingredients &amp; nutrition</a>' +
      '</div></div>';
  }).join("");

  /* Hover: the pack lifts off the shelf, tilts toward the cursor and catches the light */
  if (canHover && !reduce) {
    $$(".facing", shelf).forEach(function (f) {
      var pouch = $(".pouch", f), raf = 0, px = 0, py = 0;
      f.addEventListener("pointermove", function (e) {
        var r = pouch.getBoundingClientRect();
        px = (e.clientX - r.left) / r.width; py = (e.clientY - r.top) / r.height;
        if (!raf) raf = requestAnimationFrame(function () {
          raf = 0;
          pouch.style.setProperty("--rx", Math.max(-.6, Math.min(.6, px - .5)).toFixed(3));
          pouch.style.setProperty("--ry", Math.max(-.6, Math.min(.6, py - .5)).toFixed(3));
          pouch.style.setProperty("--mx", (px * 100).toFixed(1) + "%");
          pouch.style.setProperty("--my", (py * 100).toFixed(1) + "%");
        });
      });
      f.addEventListener("pointerleave", function () {
        pouch.style.setProperty("--rx", 0); pouch.style.setProperty("--ry", 0);
      });
    });
  }

  /* Quantity steppers */
  document.addEventListener("click", function (e) {
    var s = e.target.closest("[data-step]"); if (!s) return;
    var out = s.parentNode.querySelector("[data-q]");
    out.textContent = Math.max(1, Math.min(99, (+out.textContent || 1) + (+s.dataset.step)));
  });

  /* ---------- The basket ---------- */
  var basket = store.get("rf-basket", {}), sub = store.get("rf-sub", false), fresh = null;
  Object.keys(basket).forEach(function (k) { if (!BY[k]) delete basket[k]; });
  var paper = $("#paper"), tab = $("#docketTab"), autoClose = 0;

  function save() { store.set("rf-basket", basket); }
  function render() {
    var ids = Object.keys(basket), n = 0, total = 0;
    ids.forEach(function (k) { n += basket[k]; total += basket[k] * BY[k].price; });
    $$("[data-count]").forEach(function (el) { el.textContent = n; });
    $$("[data-open-basket]").forEach(function (el) { el.setAttribute("aria-label", "Basket, " + n + (n === 1 ? " item" : " items")); });
    tab.classList.toggle("hidden-empty", n === 0 && paper.hidden);
    var time = new Date().toLocaleTimeString("en-GB", { hour: "2-digit", minute: "2-digit" });
    var off = sub ? total * 0.1 : 0;
    paper.innerHTML =
      '<div class="ph"><span class="logo logo--h" role="img" aria-label="Regency Foods"></span><span class="when">' + time + '</span></div>' +
      (ids.length ? ids.map(function (k) {
        var p = BY[k];
        return '<div class="ln' + (k === fresh ? " new" : "") + '"><span class="q"><button type="button" data-dec="' + k + '" aria-label="Remove one ' + p.name + '">−</button>' + basket[k] + '×<button type="button" data-inc="' + k + '" aria-label="Add one ' + p.name + '">+</button></span>' +
          '<span class="nm">' + p.name + '<small>' + p.descriptor + '</small></span><span>' + gbp.format(p.price * basket[k]) + '</span></div>';
      }).join("") +
        '<label class="sub"><input type="checkbox" id="subBox"' + (sub ? " checked" : "") + '> Subscribe &amp; save 10% on every order</label>' +
        '<div class="tot"><div><span>Subtotal</span><span>' + gbp.format(total) + '</span></div>' +
        (sub ? '<div class="save"><span>Subscribe &amp; save</span><span>−' + gbp.format(off) + '</span></div>' : '') +
        '<div><span>Delivery</span><span>Next day</span></div>' +
        '<div class="g"><span>Total</span><span>' + gbp.format(total - off) + '</span></div></div>' +
        '<button class="btn btn--green send" type="button" id="send">Checkout <span aria-hidden="true">→</span></button>' +
        '<p class="cut">Order today, delivered tomorrow.</p>'
      : '<p class="empty">Nothing added to your basket yet. Take something off the shelf.</p>');
    fresh = null;
  }
  function openPaper(print) {
    paper.hidden = false; tab.classList.remove("hidden-empty"); tab.setAttribute("aria-expanded", "true");
    if (print && !reduce) { paper.classList.remove("printing"); void paper.offsetWidth; paper.classList.add("printing"); }
  }
  function closePaper() { paper.hidden = true; tab.setAttribute("aria-expanded", "false"); render(); }
  function scheduleClose() {
    clearTimeout(autoClose);
    autoClose = setTimeout(function () { if (!paper.matches(":hover") && !paper.contains(document.activeElement)) closePaper(); }, 4000);
  }
  function add(id, q) {
    basket[id] = (basket[id] || 0) + q; fresh = id; save(); render();
    openPaper(true); scheduleClose();
    $$("[data-count]").forEach(function (el) { el.classList.remove("bump"); void el.offsetWidth; el.classList.add("bump"); });
    var bay = $('[data-bay="' + id + '"]');
    if (bay && !reduce) { bay.classList.remove("picked"); void bay.offsetWidth; bay.classList.add("picked"); }
    toast(q + " × " + BY[id].name + " added to your basket");
  }
  tab.addEventListener("click", function () { clearTimeout(autoClose); if (paper.hidden) { openPaper(true); } else { closePaper(); } });
  paper.addEventListener("pointerenter", function () { clearTimeout(autoClose); });
  paper.addEventListener("change", function (e) { if (e.target.id === "subBox") { sub = e.target.checked; store.set("rf-sub", sub); render(); } });

  document.addEventListener("click", function (e) {
    var t;
    if ((t = e.target.closest("[data-add]"))) {
      var q = t.parentNode.querySelector("[data-q]");
      var scope = t.closest("[data-plan-scope]"), plan = scope && $('input[name="plan"]:checked', scope);
      if (plan) { sub = plan.value === "sub"; store.set("rf-sub", sub); }
      add(t.dataset.add, q ? +q.textContent : 1);
      if (q) q.textContent = 1;
    } else if ((t = e.target.closest("[data-inc]"))) { clearTimeout(autoClose); basket[t.dataset.inc]++; save(); render(); }
    else if ((t = e.target.closest("[data-dec]"))) { clearTimeout(autoClose); var k = t.dataset.dec; if (--basket[k] <= 0) delete basket[k]; save(); render(); }
    else if (e.target.closest("[data-open-basket]")) { clearTimeout(autoClose); openPaper(true); var b = $("#send") || tab; b.focus(); }
    else if (e.target.closest("#send")) toast("Checkout isn't connected yet. Plug in your payment provider here.");
  });
  document.addEventListener("keydown", function (e) { if (e.key === "Escape" && !paper.hidden) { closePaper(); tab.focus(); } });

  /* ---------- Product pages: #/product/<id>  (and #/product/<id>/nutrition) ---------- */
  var home = $("#main"), pp = $("#productPage"), baseTitle = document.title, homeY = 0;
  var STORAGE = "Store in a cool, dry place away from direct sunlight. Once opened, reseal the pack and enjoy within 4 weeks.";
  function nutritionTable(p) {
    return '<table class="pp-table"><thead><tr><th scope="col">Typical values</th><th scope="col">Per 100 g</th><th scope="col">Per 30 g handful</th></tr></thead><tbody>' +
      p.nutrition.map(function (r) {
        var per30 = r[1].replace(/([\d.]+)/g, function (n) { var v = +n * .3; return v >= 100 ? Math.round(v) : v >= 10 ? v.toFixed(1) : v >= .01 ? v.toFixed(2).replace(/0$/, "") : "<0.01"; });
        return '<tr' + (r[2] ? ' class="ind"' : '') + '><th scope="row">' + r[0] + '</th><td>' + r[1] + '</td><td>' + per30 + '</td></tr>';
      }).join("") + '</tbody></table>';
  }
  function card(q) {
    return '<a class="pp-card" href="#/product/' + q.id + '" style="--tint:' + q.tint + '">' +
      '<span class="pp-card-img"><img src="' + q.pack + '" alt="" loading="lazy"></span>' +
      '<span class="pp-card-txt"><b>' + q.name + '</b><span>' + q.descriptor + ', 1 kg</span><span class="pp-card-price">' + gbp.format(q.price) + '</span></span>' +
      '<span class="pp-card-go" aria-hidden="true">→</span></a>';
  }
  function productHTML(p) {
    var subPrice = gbp.format(p.price * .9);
    return '<nav class="wrap pp-crumbs" aria-label="Breadcrumb"><a href="#top">Home</a><span aria-hidden="true">/</span><a href="#range">Nuts &amp; Seeds</a><span aria-hidden="true">/</span><span aria-current="page">' + p.name + '</span></nav>' +
      '<section class="wrap pp-top" aria-labelledby="ppName">' +
        '<div class="pp-stage" style="--tint:' + p.tint + '">' +
          '<div class="pp-pouch" id="pouch" data-view-now="front">' +
            '<img class="on" data-img="front" src="' + p.pack + '" alt="Front of the Regency Foods ' + p.name + ' 1 kg pouch">' +
            '<img data-img="back" src="' + p.back + '" alt="Back of the ' + p.name + ' pouch: ingredients, allergy advice and nutrition">' +
            '<img data-img="side" src="' + p.side + '" alt="Side of the ' + p.name + ' pouch, showing the gusset">' +
          '</div>' +
          '<div class="pp-views" role="group" aria-label="Pouch view">' +
            '<button type="button" data-view="front" aria-pressed="true">Front</button><button type="button" data-view="back" aria-pressed="false">Back</button><button type="button" data-view="side" aria-pressed="false">Side</button>' +
          '</div>' +
        '</div>' +
        '<div class="pp-info" data-plan-scope>' +
          '<h1 id="ppName">' + p.name + '</h1>' +
          '<p class="pp-desc">' + p.descriptor + ' · 1 kg resealable pack</p>' +
          '<p class="pp-price">' + gbp.format(p.price) + '<small>' + gbp.format(p.price / 10) + ' per 100 g</small></p>' +
          '<p class="pp-about">' + esc(p.about) + '</p>' +
          '<fieldset class="pp-plan"><legend class="sr">How would you like to buy?</legend>' +
            '<label><input type="radio" name="plan" value="once"' + (sub ? '' : ' checked') + '><span><b>One-off purchase</b><em>' + gbp.format(p.price) + '</em></span></label>' +
            '<label><input type="radio" name="plan" value="sub"' + (sub ? ' checked' : '') + '><span><b>Subscribe &amp; save 10%</b><em>' + subPrice + '</em><small>Added to every order. Skip or cancel any time.</small></span></label>' +
          '</fieldset>' +
          '<div class="buy"><span class="qty" role="group" aria-label="Quantity"><button type="button" data-step="-1" aria-label="Decrease">−</button><output data-q>1</output><button type="button" data-step="1" aria-label="Increase">+</button></span>' +
          '<button class="btn btn--green" type="button" data-add="' + p.id + '">Add to basket</button></div>' +
          '<p class="pp-ship"><span class="dot" aria-hidden="true"></span>Order in <b data-timer>00:00:00</b> for delivery tomorrow</p>' +
          '<ul class="pp-facts"><li>1 kg resealable pouch</li><li>Next-day UK delivery</li><li>Trade pricing available</li></ul>' +
        '</div>' +
      '</section>' +
      '<section class="wrap pp-details" aria-label="Product details">' +
        '<details open><summary>Description</summary><div><p>' + esc(p.about) + '</p><p>Packed in our 1 kg resealable pouch, so it stays fresh from the first handful to the last, in a busy kitchen or at home.</p></div></details>' +
        '<details id="ppIngredients"><summary>Ingredients &amp; allergens</summary><div><p><b class="k">Ingredients</b> ' + p.ingredients + '</p><p><b class="k">Allergy advice</b> ' + p.allergy + '</p></div></details>' +
        '<details id="ppNutrition"><summary>Nutrition</summary><div>' + nutritionTable(p) + '</div></details>' +
        '<details><summary>Storage</summary><div><p>' + STORAGE + '</p></div></details>' +
        '<details><summary>Delivery</summary><div><p>Order before midnight and it arrives the next day, nationwide, from our North London hub. Trade customers can set up a standing order with their account manager.</p></div></details>' +
      '</section>' +
      '<section class="pp-more" aria-labelledby="ppMore"><div class="wrap">' +
        '<h2 id="ppMore">More from our own range</h2>' +
        '<div class="pp-cards">' + RANGE.filter(function (q) { return q.id !== p.id; }).map(card).join("") + '</div>' +
      '</div></section>' +
      '<section class="wrap pp-trade"><div><h2>Buying for a kitchen?</h2><p>Open a trade account for wholesale pricing, standing orders and an account manager who knows your menu.</p></div>' +
        '<a class="btn btn--cream" href="#trade">Open a trade account <span aria-hidden="true">→</span></a></section>';
  }
  var VIEWS = ["front", "back", "side"];
  function setView(v) {
    var box = $("#pouch"); if (!box) return;
    box.dataset.viewNow = v;
    $$("[data-img]", box).forEach(function (i) { i.classList.toggle("on", i.dataset.img === v); });
    $$("[data-view]", pp).forEach(function (b) { b.setAttribute("aria-pressed", String(b.dataset.view === v)); });
  }
  function showProduct(id, part) {
    var p = BY[id];
    if (pp.hidden) homeY = window.scrollY;
    pp.innerHTML = productHTML(p);
    home.hidden = true; pp.hidden = false;
    document.title = p.name + " | Regency Foods";
    tick();
    if (part === "nutrition") {
      var d = $("#ppNutrition"); d.open = true; $("#ppIngredients").open = true;
      requestAnimationFrame(function () { d.scrollIntoView({ block: "start" }); });
    } else window.scrollTo(0, 0);
    pp.focus({ preventScroll: true });
  }
  function route() {
    var m = location.hash.match(/^#\/product\/(\w+)(?:\/(\w+))?/);
    if (m && BY[m[1]]) { showProduct(m[1], m[2]); return; }
    if (!pp.hidden) {
      pp.hidden = true; home.hidden = false; pp.innerHTML = ""; document.title = baseTitle;
      var el = location.hash.length > 1 && document.getElementById(location.hash.slice(1));
      requestAnimationFrame(function () { if (el) el.scrollIntoView(); else window.scrollTo(0, homeY); });
    }
  }
  pp.addEventListener("click", function (e) {
    var v = e.target.closest("[data-view]");
    if (v) { setView(v.dataset.view); return; }
    var box = e.target.closest("#pouch");
    if (box) setView(VIEWS[(VIEWS.indexOf(box.dataset.viewNow) + 1) % VIEWS.length]);
  });
  window.addEventListener("hashchange", route);
  route();

  /* ---------- Category cards (aisle pages come next) ---------- */
  $$("[data-aisle]").forEach(function (a) {
    a.addEventListener("click", function (e) { e.preventDefault(); toast(a.dataset.aisle + ": aisle page coming soon"); });
  });

  /* ---------- Navigation ---------- */
  var mb = $("#menuBtn"), mn = $("#mnav");
  mb.addEventListener("click", function () { var open = mn.hidden; mn.hidden = !open; mb.setAttribute("aria-expanded", String(open)); mb.setAttribute("aria-label", open ? "Close menu" : "Open menu"); });
  $$("a", mn).forEach(function (a) { a.addEventListener("click", function () { mn.hidden = true; mb.setAttribute("aria-expanded", "false"); mb.setAttribute("aria-label", "Open menu"); }); });
  if ("IntersectionObserver" in window) {
    var links = $$(".nav a");
    var io = new IntersectionObserver(function (es) { es.forEach(function (en) { if (en.isIntersecting) links.forEach(function (a) { a.setAttribute("aria-current", a.getAttribute("href") === "#" + en.target.id ? "true" : "false"); }); }); }, { rootMargin: "-45% 0px -50% 0px" });
    ["shop", "range", "delivery", "trade", "story"].forEach(function (id) { var el = document.getElementById(id); if (el) io.observe(el); });
  }

  /* ---------- Forms ---------- */
  var tf = $("#tradeForm");
  tf.addEventListener("submit", function (e) {
    e.preventDefault();
    var req = $$("[required]", tf);
    var bad = req.filter(function (i) { return !i.value.trim() || (i.type === "email" && !/^\S+@\S+\.\S+$/.test(i.value)); });
    req.forEach(function (i) { i.setAttribute("aria-invalid", bad.indexOf(i) > -1 ? "true" : "false"); });
    if (bad.length) { $("#tfErr").textContent = "Please add your name, business and a valid work email."; bad[0].focus(); return; }
    var biz = esc($("#tfBiz").value.trim());
    tf.innerHTML = '<div class="received"><span class="stamp">Received</span><h3>Thanks, ' + biz + '.</h3><p class="note">Your request is with us. An account manager will be in touch shortly with pricing.</p></div>';
  });
  $("#newsForm").addEventListener("submit", function (e) {
    e.preventDefault();
    var i = $("#newsEmail"), ok = /^\S+@\S+\.\S+$/.test(i.value);
    i.setAttribute("aria-invalid", ok ? "false" : "true");
    $("#newsMsg").textContent = ok ? "You're on the list. Look out for new arrivals and offers." : "Enter a valid email address to subscribe.";
    if (ok) this.reset();
  });

  var tt;
  function toast(m) { var t = $("#toast"); t.textContent = m; t.classList.add("show"); clearTimeout(tt); tt = setTimeout(function () { t.classList.remove("show"); }, 2200); }
  render();
})();
